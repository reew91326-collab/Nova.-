# Nova — Real AI Connection

هذا المشروع يربط واجهة Nova بواجهة OpenAI Responses API.

## 1) المتطلبات
- Node.js 20+
- مفتاح OpenAI API

## 2) تشغيل السيرفر
داخل مجلد server:

```bash
npm install
```

انسخ `.env.example` إلى `.env` وضع مفتاحك:

```env
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-6-luna
PORT=3000
```

ثم:

```bash
npm start
```

اختبر:
`http://localhost:3000/health`

## 3) ربط واجهة Nova
الواجهة ترسل POST إلى:
`http://localhost:3000/api/chat`

مثال:

```js
const response = await fetch("http://localhost:3000/api/chat", {
  method: "POST",
  headers: {"Content-Type":"application/json"},
  body: JSON.stringify({
    userName: "صالح",
    messages: [
      {role:"user", content:"هلا Nova"}
    ]
  })
});
const data = await response.json();
console.log(data.reply);
```

## الأمان
لا تضع OPENAI_API_KEY داخل HTML أو تطبيق الجوال. المفتاح يبقى في السيرفر فقط.

المشروع يستخدم Responses API، وهي واجهة OpenAI الحالية للتكاملات الجديدة.
