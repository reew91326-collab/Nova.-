import express from "express";
import cors from "cors";
import OpenAI from "openai";
import "dotenv/config";

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is missing. Add it to server/.env before starting.");
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(cors());
app.use(express.json({ limit: "2mb" }));

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "nova-api" });
});

app.post("/api/chat", async (req, res) => {
  try {
    const { messages, userName = "صالح" } = req.body ?? {};

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "messages must be a non-empty array" });
    }

    const safeMessages = messages
      .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .slice(-30);

    const input = safeMessages.map(m => ({
      role: m.role,
      content: m.content
    }));

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-luna",
      instructions: `أنت Nova، مساعد ذكاء اصطناعي ودود وذكي يتحدث العربية بشكل طبيعي.
اسم المستخدم ${userName}. كن قريباً ولطيفاً بدون مبالغة، وكن واضحاً ومفيداً.
لا تدّعِ أنك إنسان. إذا لم تعرف شيئاً قل ذلك بوضوح.
أجب بنفس لغة المستخدم، واستخدم تنسيقاً واضحاً عند الحاجة.`,
      input
    });

    res.json({
      reply: response.output_text,
      responseId: response.id
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "تعذر الحصول على رد من Nova.",
      detail: process.env.NODE_ENV === "development" ? error.message : undefined
    });
  }
});

app.listen(port, () => {
  console.log(`Nova API running on http://localhost:${port}`);
});
