async function askNova(message, history = [], userName = "صالح") {
  const response = await fetch("http://localhost:3000/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      userName,
      messages: [...history, { role: "user", content: message }]
    })
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || "Nova API error");
  }

  return data.reply;
}

// Example:
// askNova("هلا Nova").then(console.log);
